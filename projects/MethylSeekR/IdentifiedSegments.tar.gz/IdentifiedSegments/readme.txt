The files ending in _PMDs.tab contain the coordinates of the inferred partially
methylated domains. The files ending in _UMRsLMRs.tab contain the
coordinates and additional metadata for the identified UMRs and LMRs.  The
metadata includes the region type (LMR or UMR), the number of covered CpGs
(by at least 5 reads) per region (nCG.segmentation), the number of CpGs in
the genome per region (nCG.seq), the mean methylation (mean.meth) and the
median methylation per region (median.meth).
