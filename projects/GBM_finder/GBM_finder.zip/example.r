source('GBM_finder.r')

hits <- scanForGBMs("seqs.fa","GBM_scores.tab")

