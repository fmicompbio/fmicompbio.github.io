scanForGBMs <- function(sequenceFile,paramFile) {
  # scan a fasta file with sequences for GBMs.
  # arguments:
  # 
  # sequenceFile  : name of the fasta file containing the sequences
  # paramFile     : file containing GBM scores

  library(Biostrings)

  # load files
  seqs <- read.DNAStringSet(sequenceFile, format="fasta")
  mots <- read.delim(paramFile,header=FALSE)
  colnames(mots)=c("mot","score","level")

  # perform motif search
  hitsList=lapply(mots[,1],function(x) as.data.frame(unlist(vmatchPattern(as.character(x),seqs))))

  # convert results to table and sort by query
  hitsTabRaw <- cbind(do.call("rbind", hitsList),mot=rep(mots[,1],sapply(hitsList,nrow)))

  # add the score and the level of a site
  hitsTabRawScore <- merge(hitsTabRaw,mots,by.x="mot",by.y=1)
  hitsTab <- hitsTabRawScore[order(hitsTabRawScore$names),c(5,2,3,1,6,7)]

  hitsTab
}
